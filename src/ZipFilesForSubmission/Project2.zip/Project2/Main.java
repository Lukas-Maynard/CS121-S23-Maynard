/*
**************************************************************
            Project #2 - Pokemon Class
            Name: Lukas Maynard
            Data Structures Date: Date of Submission (3/30/2023)
 *************************************************************
            Main::main()
        Uses PokemonSelection Class to create and display info.
 *************************************************************
*/
package src.Project2;

public class Main {
    public static void main(String[] args) {
        PokemonSelection pokemonSelect = new PokemonSelection();
        pokemonSelect.assignPokemon(2);
    }
}
