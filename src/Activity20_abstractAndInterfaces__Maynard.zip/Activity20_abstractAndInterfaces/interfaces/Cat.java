package src.Activity20_abstractAndInterfaces.interfaces;

public class Cat implements animal {
    @Override
    public void makeSound() {
        System.out.println("Meow");
    }
}
