package src.Activity20_abstractAndInterfaces.interfaces;

public class Dog implements animal {
    @Override
    public void makeSound() {
        System.out.println("Bark");
    }
}
