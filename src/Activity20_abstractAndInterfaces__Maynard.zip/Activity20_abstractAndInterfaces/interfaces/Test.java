package src.Activity20_abstractAndInterfaces.interfaces;

public class Test {
    public static void main(String[] args) {
        Dog pet1 = new Dog();
        pet1.makeSound();

        Cat pet2 = new Cat();
        pet2.makeSound();
    }
}
