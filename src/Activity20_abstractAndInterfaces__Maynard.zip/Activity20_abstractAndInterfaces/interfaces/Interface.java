package src.Activity20_abstractAndInterfaces.interfaces;

interface animal{

    void makeSound();
}
