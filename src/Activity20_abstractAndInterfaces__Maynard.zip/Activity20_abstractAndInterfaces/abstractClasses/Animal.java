package src.Activity20_abstractAndInterfaces.abstractClasses;

public abstract class Animal {
    public abstract void makeSound();
}
