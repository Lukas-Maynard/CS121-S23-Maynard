package src.Activity28_sets_and_iterators;

public class Main {
    public static void main(String[] args) {
        StudentSet student = new StudentSet();
        student.addStudent();
        student.displayStudents();
    }
}
